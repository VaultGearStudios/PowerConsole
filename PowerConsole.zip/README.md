# PowerConsole
  A webview based inter store database
## Database
  [Supabase](https://supabase.com/)
## hCaptcha
  [hCaptcha](https://www.hcaptcha.com/)
