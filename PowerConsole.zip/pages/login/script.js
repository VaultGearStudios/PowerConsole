import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://jbrrfuldmrhxtcsuuqjr.supabase.co'
const supabaseKey = process.env.SUPABASE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)
const username = document.getElementById('user').value;
const password = document.getElementById('pass').value;

$.ajax({
  url: '/login_check',
  type: 'POST',
  dataType: 'json',
  data: {ouser: username, opass: password},
  success: function(response) {
    if (response.success) {
      window.location.replace(response.redirect_url);
    } else {
      window.location.replace(response.redirect_url);
    }
  }
});
