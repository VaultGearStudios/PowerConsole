import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://jbrrfuldmrhxtcsuuqjr.supabase.co'
const supabaseKey = process.env.SUPABASE_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

let { data: PowerconsoleLogin, error } = await supabase
  .from('PowerconsoleLogin')
  .select('id')


let { data: PowerconsoleLogin, error } = await supabase
  .from('PowerconsoleLogin')
  .select('user')


let { data: PowerconsoleLogin, error } = await supabase
  .from('PowerconsoleLogin')
  .select('location')


let { data: PowerconsoleLogin, error } = await supabase
  .from('PowerconsoleLogin')
  .select('created_at')


let { data: PowerconsoleLogin, error } = await supabase
  .from('PowerconsoleLogin')
  .select('pass')
